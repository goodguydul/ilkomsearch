<?php
if ($title !== null) {
    ?>
    <h3 class="title">Title :: <?= $title ?></h3>
<?php
}